<div class="container">
	<h4><?php echo $data_sertifikasi->nama_sertifikasi ?></h4>
	<div style="text-align: center;">
		<embed type="application/pdf" src="../assets/documents/<?php echo $data_sertifikasi->kode_sertifikasi ?>.pdf" width="100%" height="450"></embed>
	</div>
</div>