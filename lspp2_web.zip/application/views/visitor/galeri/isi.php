<div class="container">
	<?php
	foreach ($list_galeri as $k) {
		?>
		<div class="gallery-wrapper">
			<div class="img-gallery-wrapper">
				<img src="<?php echo base_url().'' ?>">
			</div>
		</div>

		<?php
	}
	?>

</div>