<button type="button" class="btn btn-danger list-data">Kembali</button>

<form id="form_diskusi" method="post" enctype="multipart/form-data">
	<button class="btn btn-primary btn-tambah-diskusi">+</button>
	<ul class="list-unstyled" id="list-diskusi">
	<?php 

	for ($i=0; $i < 5; $i++) { 
		echo '<li><textarea name="anu">test</textarea></li>';
	}

	// foreach($list_diskusi as $ld)
	// {
	// 	echo '<li id="'.$ld->kuesioner_id.'"><textarea name="anu">'.$ld->detail_diskusi.'</textarea></li>';
	// }
	?>
	</ul>
</form>

<script type="text/javascript">
	$('.btn-tambah-diskusi').click(function() {
		$('#list-diskusi').append(`<li><textarea name="anu">test</textarea></li>`)
	})

	$("#list-diskusi").sortable({
		placeholder : "ui-state-highlight",
		update  : function(event, ui) {
			// var page_id_array = new Array();
			// $('#page_list li').each(function(){
			// 	page_id_array.push($(this).attr("id"));
			// });
		}
	 });
</script>